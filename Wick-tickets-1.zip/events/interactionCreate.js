const config = require('../config');
const sectionManager = require('../utils/sectionManager');
const ticketManager = require('../utils/ticketManager');
const settingsManager = require('../utils/settingsManager');
const modals = require('../components/modals');
const selects = require('../components/selects');
const buttons = require('../components/buttons');
const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');

let tempData = new Map();
if (!global.sendpanelTempData) global.sendpanelTempData = new Map();

module.exports.tempData = tempData;

module.exports = {
  name: 'interactionCreate',
  async execute(interaction, client) {
    const hasAdminPermission = interaction.user.id === config.ownerId || 
                               interaction.member?.roles.cache.some(role => config.adminRoles.includes(role.id));

    if (interaction.isButton()) {
      if (interaction.customId === 'tpanel_add_section') {
        const modal = modals.createAddSectionModal();
        await interaction.showModal(modal);
      }

      if (interaction.customId === 'tpanel_edit_section') {
        const { selectRow } = selects.createSectionSelectMenu(0, 'edit_section_select');
        await interaction.reply({ content: 'اختر القسم الذي تريد تعديله:', components: [selectRow], ephemeral: true });
      }

      if (interaction.customId === 'edit_section_add_option') {
        const modal = modals.createAddOptionModal();
        await interaction.showModal(modal);
      }

      if (interaction.customId === 'edit_section_edit_option') {
        const sectionId = tempData.get(`section_${interaction.user.id}`);
        if (!sectionId) return interaction.reply({ content: '❌ حدث خطأ. حاول مرة أخرى.', ephemeral: true });

        const optionSelect = selects.createOptionSelectMenu(sectionId, 'select_option_to_edit');
        await interaction.reply({ content: 'اختر الخيار الذي تريد تعديله:', components: [optionSelect], ephemeral: true });
      }

      if (interaction.customId === 'edit_section_edit_embed') {
        tempData.set(`embed_type_${interaction.user.id}`, 'section');
        tempData.delete(`option_index_${interaction.user.id}`);
        const embedButtons = buttons.createEmbedEditButtons();
        const removeButtons = buttons.createRemoveImageButtons();
        await interaction.reply({ content: 'اختر ما تريد تعديله في الإيمبد:', components: [embedButtons, removeButtons], ephemeral: true });
      }

      if (interaction.customId === 'edit_section_edit_ticket') {
        const sectionId = tempData.get(`section_${interaction.user.id}`);
        if (!sectionId) {
          return interaction.reply({ content: '❌ حدث خطأ. حاول مرة أخرى.', ephemeral: true });
        }

        const section = sectionManager.getSection(sectionId);
        if (!section) {
          return interaction.update({ content: '❌ القسم غير موجود.', components: [] });
        }

        if (!section.options || section.options.length === 0) {
          return interaction.update({ content: '❌ لا توجد خيارات في هذا القسم. أضف خيارًا أولاً.', components: [] });
        }

        const optionSelect = selects.createOptionSelectMenu(sectionId, 'select_option_edit_ticket');
        await interaction.update({ content: 'اختر الخيار لتعديل رسالة التذكرة:', components: [optionSelect] });
      }

      if (interaction.customId === 'embed_edit_title') {
        const sectionId = tempData.get(`section_${interaction.user.id}`);
        if (!sectionId) {
          return interaction.reply({ content: '❌ حدث خطأ. لم يتم العثور على القسم.', ephemeral: true });
        }

        const section = sectionManager.getSection(sectionId);
        if (!section) {
          return interaction.reply({ content: '❌ القسم غير موجود.', ephemeral: true });
        }

        const embedType = tempData.get(`embed_type_${interaction.user.id}`) || 'section';
        const optionIndex = tempData.get(`option_index_${interaction.user.id}`);

        let currentTitle = '';
        if (embedType === 'ticket' && optionIndex !== undefined) {
          if (!section.options || !section.options[optionIndex]) {
            return interaction.reply({ content: '❌ الخيار غير موجود.', ephemeral: true });
          }
          currentTitle = section.options[optionIndex].ticketEmbed?.title || '';
        } else {
          currentTitle = section.embed?.title || '';
        }

        const modal = modals.createEditEmbedTitleModal(currentTitle);
        await interaction.showModal(modal);
      }

      if (interaction.customId === 'embed_edit_description') {
        const sectionId = tempData.get(`section_${interaction.user.id}`);
        if (!sectionId) {
          return interaction.reply({ content: '❌ حدث خطأ. لم يتم العثور على القسم.', ephemeral: true });
        }

        const section = sectionManager.getSection(sectionId);
        if (!section) {
          return interaction.reply({ content: '❌ القسم غير موجود.', ephemeral: true });
        }

        const embedType = tempData.get(`embed_type_${interaction.user.id}`) || 'section';
        const optionIndex = tempData.get(`option_index_${interaction.user.id}`);

        let currentDesc = '';
        if (embedType === 'ticket' && optionIndex !== undefined) {
          if (!section.options || !section.options[optionIndex]) {
            return interaction.reply({ content: '❌ الخيار غير موجود.', ephemeral: true });
          }
          currentDesc = section.options[optionIndex].ticketEmbed?.description || '';
        } else {
          currentDesc = section.embed?.description || '';
        }

        const modal = modals.createEditEmbedDescModal(currentDesc);
        await interaction.showModal(modal);
      }

      if (interaction.customId === 'embed_edit_images') {
        const sectionId = tempData.get(`section_${interaction.user.id}`);
        if (!sectionId) {
          return interaction.reply({ content: '❌ حدث خطأ. لم يتم العثور على القسم.', ephemeral: true });
        }

        const section = sectionManager.getSection(sectionId);
        if (!section) {
          return interaction.reply({ content: '❌ القسم غير موجود.', ephemeral: true });
        }

        const embedType = tempData.get(`embed_type_${interaction.user.id}`) || 'section';
        const optionIndex = tempData.get(`option_index_${interaction.user.id}`);

        let currentThumbnail = '';
        let currentImage = '';
        if (embedType === 'ticket' && optionIndex !== undefined) {
          if (!section.options || !section.options[optionIndex]) {
            return interaction.reply({ content: '❌ الخيار غير موجود.', ephemeral: true });
          }
          currentThumbnail = section.options[optionIndex].ticketEmbed?.thumbnail || '';
          currentImage = section.options[optionIndex].ticketEmbed?.image || '';
        } else {
          currentThumbnail = section.embed?.thumbnail || '';
          currentImage = section.embed?.image || '';
        }

        const modal = modals.createEditEmbedImagesModal(currentThumbnail, currentImage);
        await interaction.showModal(modal);
      }

      if (interaction.customId === 'embed_edit_footer') {
        const sectionId = tempData.get(`section_${interaction.user.id}`);
        if (!sectionId) {
          return interaction.reply({ content: '❌ حدث خطأ. لم يتم العثور على القسم.', ephemeral: true });
        }

        const section = sectionManager.getSection(sectionId);
        if (!section) {
          return interaction.reply({ content: '❌ القسم غير موجود.', ephemeral: true });
        }

        const embedType = tempData.get(`embed_type_${interaction.user.id}`) || 'section';
        const optionIndex = tempData.get(`option_index_${interaction.user.id}`);

        let currentText = '';
        let currentIcon = '';
        if (embedType === 'ticket' && optionIndex !== undefined) {
          if (!section.options || !section.options[optionIndex]) {
            return interaction.reply({ content: '❌ الخيار غير موجود.', ephemeral: true });
          }
          currentText = section.options[optionIndex].ticketEmbed?.footer?.text || '';
          currentIcon = section.options[optionIndex].ticketEmbed?.footer?.icon || '';
        } else {
          currentText = section.embed?.footer?.text || '';
          currentIcon = section.embed?.footer?.icon || '';
        }

        const modal = modals.createEditEmbedFooterModal(currentText, currentIcon);
        await interaction.showModal(modal);
      }

      if (interaction.customId === 'embed_edit_color') {
        const sectionId = tempData.get(`section_${interaction.user.id}`);
        if (!sectionId) {
          return interaction.reply({ content: '❌ حدث خطأ. لم يتم العثور على القسم.', ephemeral: true });
        }

        const section = sectionManager.getSection(sectionId);
        if (!section) {
          return interaction.reply({ content: '❌ القسم غير موجود.', ephemeral: true });
        }

        const embedType = tempData.get(`embed_type_${interaction.user.id}`) || 'section';
        const optionIndex = tempData.get(`option_index_${interaction.user.id}`);

        let currentColor = '#5865F2';
        if (embedType === 'ticket' && optionIndex !== undefined) {
          if (!section.options || !section.options[optionIndex]) {
            return interaction.reply({ content: '❌ الخيار غير موجود.', ephemeral: true });
          }
          currentColor = section.options[optionIndex].ticketEmbed?.color || '#5865F2';
        } else {
          currentColor = section.embed?.color || '#5865F2';
        }

        const modal = modals.createEditEmbedColorModal(currentColor);
        await interaction.showModal(modal);
      }

      if (interaction.customId === 'embed_remove_thumbnail') {
        const sectionId = tempData.get(`section_${interaction.user.id}`);
        const embedType = tempData.get(`embed_type_${interaction.user.id}`);
        const optionIndex = tempData.get(`option_index_${interaction.user.id}`);

        if (embedType === 'ticket' && optionIndex !== undefined) {
          sectionManager.updateOptionTicketEmbed(sectionId, optionIndex, { thumbnail: null });
        } else {
          sectionManager.updateSectionEmbed(sectionId, { thumbnail: null });
        }
        await interaction.reply({ content: '✅ تم حذف الأيقونة.', ephemeral: true });
      }

      if (interaction.customId === 'embed_remove_image') {
        const sectionId = tempData.get(`section_${interaction.user.id}`);
        const embedType = tempData.get(`embed_type_${interaction.user.id}`);
        const optionIndex = tempData.get(`option_index_${interaction.user.id}`);

        if (embedType === 'ticket' && optionIndex !== undefined) {
          sectionManager.updateOptionTicketEmbed(sectionId, optionIndex, { image: null });
        } else {
          sectionManager.updateSectionEmbed(sectionId, { image: null });
        }
        await interaction.reply({ content: '✅ تم حذف الصورة.', ephemeral: true });
      }

      if (interaction.customId === 'embed_back') {
        const embedButtons = buttons.createEmbedEditButtons();
        const removeButtons = buttons.createRemoveImageButtons();
        await interaction.update({ content: 'اختر ما تريد تعديله في الإيمبد:', components: [embedButtons, removeButtons] });
      }

      if (interaction.customId === 'ticket_claim') {
        if (!hasAdminPermission) {
          return interaction.reply({ content: '❌ ليس لديك صلاحية لاستلام التذاكر.', ephemeral: true });
        }

        const ticketData = ticketManager.getTicketByChannelId(interaction.channel.id);
        if (!ticketData) return interaction.reply({ content: '❌ لم يتم العثور على التذكرة.', ephemeral: true });

        const [ticketId, ticket] = ticketData;

        if (ticket.claimed) {
          return interaction.reply({ content: `❌ التذكرة مستلمة بالفعل بواسطة <@${ticket.claimedBy}>`, ephemeral: true });
        }

        ticketManager.updateTicket(ticketId, { claimed: true, claimedBy: interaction.user.id });
        await interaction.reply({ content: `✅ تم استلام التذكرة بواسطة ${interaction.user}` });
      }

      if (interaction.customId === 'ticket_options') {
        const optionsSelect = selects.createTicketOptionsSelectMenu();
        await interaction.reply({ content: 'اختر إجراءً:', components: [optionsSelect], ephemeral: true });
      }

      if (interaction.customId === 'option_next_step') {
        const modal = modals.createAddOptionPart2Modal();
        await interaction.showModal(modal);
      }

      if (interaction.customId === 'edit_section_manage_options') {
        const manageButtons = buttons.createManageOptionsButtons();
        await interaction.reply({ content: 'اختر الإجراء:', components: [manageButtons], ephemeral: true });
      }

      if (interaction.customId === 'manage_delete_section') {
        const sectionId = tempData.get(`section_${interaction.user.id}`);
        if (!sectionId) {
          return interaction.reply({ content: '❌ حدث خطأ. حاول مرة أخرى.', ephemeral: true });
        }

        const section = sectionManager.getSection(sectionId);
        if (!section) {
          return interaction.reply({ content: '❌ القسم غير موجود.', ephemeral: true });
        }

        sectionManager.deleteSection(sectionId);
        tempData.delete(`section_${interaction.user.id}`);
        await interaction.reply({ content: `✅ تم حذف القسم **${section.name}** بنجاح!`, ephemeral: true });
      }

      if (interaction.customId === 'manage_delete_option') {
        const sectionId = tempData.get(`section_${interaction.user.id}`);
        if (!sectionId) {
          return interaction.reply({ content: '❌ حدث خطأ. حاول مرة أخرى.', ephemeral: true });
        }

        const deleteOptionSelect = selects.createDeleteOptionSelectMenu(sectionId);
        await interaction.reply({ content: 'اختر الخيار الذي تريد حذفه:', components: [deleteOptionSelect], ephemeral: true });
      }

      if (interaction.customId === 'manage_delete_all_options') {
        const sectionId = tempData.get(`section_${interaction.user.id}`);
        if (!sectionId) {
          return interaction.reply({ content: '❌ حدث خطأ. حاول مرة أخرى.', ephemeral: true });
        }

        const section = sectionManager.getSection(sectionId);
        if (!section) {
          return interaction.reply({ content: '❌ القسم غير موجود.', ephemeral: true });
        }

        const optionsCount = section.options?.length || 0;
        sectionManager.updateSection(sectionId, { options: [] });
        await interaction.reply({ content: `✅ تم حذف جميع الخيارات (${optionsCount} خيار) من القسم بنجاح!`, ephemeral: true });
      }

      if (interaction.customId === 'tpanel_ratings') {
        const ratingsSettings = settingsManager.getRatingsSettings();
        const modal = modals.createRatingsSettingsModal(ratingsSettings.channelId || '', ratingsSettings.enabled);
        await interaction.showModal(modal);
      }
    }

    if (interaction.isStringSelectMenu()) {
      if (interaction.customId === 'edit_section_select') {
        const sectionId = interaction.values[0];
        if (sectionId === 'none') {
          return interaction.update({ content: 'لا توجد أقسام متاحة.', components: [] });
        }

        tempData.set(`section_${interaction.user.id}`, sectionId);
        const editButtons = buttons.createEditSectionButtons();
        await interaction.update({ content: 'اختر ما تريد تعديله:', components: [editButtons] });
      }

      if (interaction.customId === 'sendpanel_section_select') {
        const sectionId = interaction.values[0];
        if (sectionId === 'none') {
          return interaction.update({ content: 'لا توجد أقسام متاحة.', components: [] });
        }

        const section = sectionManager.getSection(sectionId);
        const channelId = global.sendpanelTempData.get(`sendpanel_channel_${interaction.user.id}`);
        const channel = await interaction.guild.channels.fetch(channelId).catch(() => null);

        if (!channel) {
          return interaction.update({ content: '❌ القناة غير موجودة.', components: [] });
        }

        global.sendpanelTempData.delete(`sendpanel_channel_${interaction.user.id}`);

        const embed = new EmbedBuilder()
          .setTitle(section.embed.title || section.name)
          .setColor(section.embed.color || '#5865F2');

        if (section.embed.description) {
          embed.setDescription(section.embed.description);
        }

        if (section.embed.thumbnail) embed.setThumbnail(section.embed.thumbnail);
        if (section.embed.image) embed.setImage(section.embed.image);
        if (section.embed.footer?.text) {
          embed.setFooter({ 
            text: section.embed.footer.text, 
            iconURL: section.embed.footer.icon || undefined 
          });
        }

        if (section.type === 'button') {
          const rows = [];
          let currentRow = [];

          for (let i = 0; i < section.options.length; i++) {
            const option = section.options[i];
            const button = new (require('discord.js')).ButtonBuilder()
              .setCustomId(`ticket_create_${sectionId}_${i}`)
              .setLabel(option.name)
              .setStyle(require('discord.js').ButtonStyle.Primary);

            if (option.emoji && option.emoji.trim() !== '') {
              try {
                button.setEmoji(option.emoji);
              } catch (err) {
                console.log(`Invalid emoji for option ${option.name}: ${option.emoji}`);
              }
            }

            currentRow.push(button);

            if (currentRow.length === 5 || i === section.options.length - 1) {
              rows.push(new (require('discord.js')).ActionRowBuilder().addComponents(currentRow));
              currentRow = [];
            }
          }

          await channel.send({ embeds: [embed], components: rows });
        } else {
          const options = section.options.map((option, index) => {
            const optionData = {
              label: option.name,
              value: `${sectionId}_${index}`,
              description: option.description || undefined
            };

            if (option.emoji && option.emoji.trim() !== '') {
              try {

                if (/^<a?:\w+:\d+>$/.test(option.emoji) || /\p{Emoji}/u.test(option.emoji)) {
                  optionData.emoji = option.emoji;
                }
              } catch (err) {
                console.log(`Invalid emoji for option ${option.name}: ${option.emoji}`);
              }
            }

            return optionData;
          });

          const select = new (require('discord.js')).StringSelectMenuBuilder()
            .setCustomId('ticket_create_select')
            .setPlaceholder('اختر نوع التذكرة')
            .addOptions(options);

          const row = new (require('discord.js')).ActionRowBuilder().addComponents(select);
          await channel.send({ embeds: [embed], components: [row] });
        }

        await interaction.update({ content: '✅ تم إرسال اللوحة بنجاح!', components: [] });
      }

      if (interaction.customId === 'ticket_create_select') {
        const value = interaction.values[0];
        const lastUnderscoreIndex = value.lastIndexOf('_');
        const sectionId = value.substring(0, lastUnderscoreIndex);
        const optionIndex = value.substring(lastUnderscoreIndex + 1);
        const section = sectionManager.getSection(sectionId);

        if (!section || !section.options) {
          return interaction.reply({ content: '❌ حدث خطأ. القسم غير موجود.', ephemeral: true });
        }

        const parsedIndex = parseInt(optionIndex);
        if (isNaN(parsedIndex) || !section.options[parsedIndex]) {
          return interaction.reply({ content: '❌ حدث خطأ. الخيار غير موجود.', ephemeral: true });
        }

        const option = section.options[parsedIndex];

        await interaction.deferReply({ ephemeral: true });
        const result = await ticketManager.createTicket(interaction.guild, interaction.user, section, option, section.logChannelId);

        if (result.error) {
          return interaction.editReply({ content: `❌ ${result.error}` });
        }

        await interaction.editReply({ content: `✅ تم إنشاء تذكرتك ${result.channel}` });
      }

      if (interaction.customId === 'select_option_to_edit') {
        const optionIndex = parseInt(interaction.values[0]);
        const sectionId = tempData.get(`section_${interaction.user.id}`);
        const section = sectionManager.getSection(sectionId);
        const option = section.options[optionIndex];

        tempData.set(`option_index_${interaction.user.id}`, optionIndex);
        tempData.set(`editing_existing_option_${interaction.user.id}`, true);

        const modal = modals.createEditOptionModal(option);
        await interaction.showModal(modal);
      }

      if (interaction.customId === 'select_option_edit_ticket') {
        const optionIndex = parseInt(interaction.values[0]);
        tempData.set(`option_index_${interaction.user.id}`, optionIndex);
        tempData.set(`embed_type_${interaction.user.id}`, 'ticket');

        const embedButtons = buttons.createEmbedEditButtons();
        const removeButtons = buttons.createRemoveImageButtons();
        await interaction.update({ content: 'اختر ما تريد تعديله في رسالة التذكرة:', components: [embedButtons, removeButtons] });
      }

      if (interaction.customId === 'delete_option_select') {
        const optionIndex = parseInt(interaction.values[0]);
        if (optionIndex === 'none' || isNaN(optionIndex)) {
          return interaction.update({ content: 'لا توجد خيارات للحذف.', components: [] });
        }

        const sectionId = tempData.get(`section_${interaction.user.id}`);
        const section = sectionManager.getSection(sectionId);

        if (!section || !section.options[optionIndex]) {
          return interaction.reply({ content: '❌ الخيار غير موجود.', ephemeral: true });
        }

        const optionName = section.options[optionIndex].name;
        sectionManager.deleteOption(sectionId, optionIndex);
        await interaction.update({ content: `✅ تم حذف الخيار **${optionName}** بنجاح!`, components: [] });
      }

      if (interaction.customId.startsWith('rating_stars_')) {
        const parts = interaction.customId.split('_');
        const stars = parseInt(interaction.values[0]);
        const ticketId = parts[2];
        const ratingsChannelId = parts[3];

        tempData.set(`rating_stars_${interaction.user.id}`, stars);
        tempData.set(`rating_ticket_${interaction.user.id}`, ticketId);
        tempData.set(`rating_channel_${interaction.user.id}`, ratingsChannelId);

        const modal = modals.createRatingMessageModal();
        await interaction.showModal(modal);
      }

      if (interaction.customId === 'ticket_action_select') {
        const action = interaction.values[0];
        const ticketData = ticketManager.getTicketByChannelId(interaction.channel.id);

        if (!ticketData) {
          return interaction.reply({ content: '❌ لم يتم العثور على التذكرة.', ephemeral: true });
        }

        const [ticketId, ticket] = ticketData;

        if (action === 'cancel_claim') {
          if (!hasAdminPermission) {
            return interaction.reply({ content: '❌ ليس لديك صلاحية لهذا الإجراء.', ephemeral: true });
          }

          ticketManager.updateTicket(ticketId, { claimed: false, claimedBy: null });
          await interaction.reply({ content: '✅ تم إلغاء الاستلام.', ephemeral: true });
        }

        if (action === 'close_reason') {
          if (!hasAdminPermission) {
            return interaction.reply({ content: '❌ ليس لديك صلاحية لهذا الإجراء.', ephemeral: true });
          }

          const modal = modals.createCloseReasonModal();
          await interaction.showModal(modal);
        }

        if (action === 'add_user') {
          if (!hasAdminPermission) {
            return interaction.reply({ content: '❌ ليس لديك صلاحية لهذا الإجراء.', ephemeral: true });
          }

          const userSelect = selects.createUserSelectMenu();
          await interaction.reply({ content: 'اختر المستخدمين للإضافة:', components: [userSelect], ephemeral: true });
        }

        if (action === 'remove_user') {
          if (!hasAdminPermission) {
            return interaction.reply({ content: '❌ ليس لديك صلاحية لهذا الإجراء.', ephemeral: true });
          }

          if (!ticket.additionalUsers || ticket.additionalUsers.length === 0) {
            return interaction.reply({ content: '❌ لا توجد مستخدمين إضافيين في هذه التذكرة.', ephemeral: true });
          }

          const removeUserSelect = selects.createRemoveUserSelectMenu(ticket.additionalUsers);
          await interaction.reply({ content: 'اختر المستخدمين للإزالة:', components: [removeUserSelect], ephemeral: true });
        }

        if (action === 'member_reminder') {
          if (!hasAdminPermission) {
            return interaction.reply({ content: '❌ ليس لديك صلاحية لهذا الإجراء.', ephemeral: true });
          }

          const user = await interaction.guild.members.fetch(ticket.userId).catch(() => null);
          if (user) {
            try {
              await user.send(`🔔 تذكير: لديك تذكرة مفتوحة في **${interaction.guild.name}**\n${interaction.channel}`);
              await interaction.reply({ content: '✅ تم إرسال التذكير.', ephemeral: true });
            } catch {
              await interaction.reply({ content: '❌ فشل إرسال التذكير. الرسائل الخاصة مغلقة.', ephemeral: true });
            }
          }
        }

        if (action === 'request_copy') {
          await interaction.deferReply({ ephemeral: true });
          const result = await ticketManager.sendTranscript(interaction.channel, interaction.user, interaction.guild);

          if (result.error) {
            await interaction.editReply({ content: `❌ ${result.error}` });
          } else {
            await interaction.editReply({ content: '✅ تم إرسال النسخة إلى رسائلك الخاصة.' });
          }
        }
      }
    }

    if (interaction.isUserSelectMenu()) {
      if (interaction.customId === 'ticket_user_select') {
        const ticketData = ticketManager.getTicketByChannelId(interaction.channel.id);
        if (!ticketData) return;

        const [ticketId, ticket] = ticketData;
        const selectedUsers = interaction.values;

        for (const userId of selectedUsers) {
          const member = await interaction.guild.members.fetch(userId).catch(() => null);
          if (member) {
            await interaction.channel.permissionOverwrites.create(member, {
              ViewChannel: true,
              SendMessages: true,
              ReadMessageHistory: true
            });
          }
        }

        const currentUsers = ticket.additionalUsers || [];
        const updatedUsers = [...new Set([...currentUsers, ...selectedUsers])];
        ticketManager.updateTicket(ticketId, { additionalUsers: updatedUsers });

        await interaction.reply({ content: `✅ تمت إضافة ${selectedUsers.length} مستخدم إلى التذكرة.`, ephemeral: true });
      }

      if (interaction.customId === 'ticket_user_remove_select') {
        const ticketData = ticketManager.getTicketByChannelId(interaction.channel.id);
        if (!ticketData) return;

        const [ticketId, ticket] = ticketData;
        const selectedUsers = interaction.values;

        for (const userId of selectedUsers) {
          const member = await interaction.guild.members.fetch(userId).catch(() => null);
          if (member) {
            await interaction.channel.permissionOverwrites.delete(member);
          }
        }

        const currentUsers = ticket.additionalUsers || [];
        const updatedUsers = currentUsers.filter(uid => !selectedUsers.includes(uid));
        ticketManager.updateTicket(ticketId, { additionalUsers: updatedUsers });

        await interaction.reply({ content: `✅ تمت إزالة ${selectedUsers.length} مستخدم من التذكرة.`, ephemeral: true });
      }
    }

    if (interaction.isModalSubmit()) {
      if (interaction.customId === 'modal_add_section') {
        const name = interaction.fields.getTextInputValue('section_name');
        const type = interaction.fields.getTextInputValue('section_type').toLowerCase();
        const logChannelId = interaction.fields.getTextInputValue('log_channel_id');

        if (type !== 'button' && type !== 'select') {
          return interaction.reply({ content: '❌ النوع يجب أن يكون button أو select', ephemeral: true });
        }

        const sectionId = `section_${Date.now()}`;
        sectionManager.createSection(sectionId, name, type, logChannelId);

        await interaction.reply({ content: `✅ تم إنشاء القسم **${name}** بنجاح!`, ephemeral: true });
      }

      if (interaction.customId === 'modal_add_option_part1') {
        const name = interaction.fields.getTextInputValue('option_name');
        const description = interaction.fields.getTextInputValue('option_description');
        const emoji = interaction.fields.getTextInputValue('option_emoji');
        const namingPattern = interaction.fields.getTextInputValue('option_naming') || 'ticket-{num}';
        const limitStr = interaction.fields.getTextInputValue('option_limit');

        tempData.set(`option_data_${interaction.user.id}`, {
          name,
          description,
          emoji,
          namingPattern,
          maxTickets: limitStr ? parseInt(limitStr) : null
        });

        const nextButton = buttons.createNextButton('option_next_step');
        await interaction.reply({ 
          content: 'انقر على "التالي" للمتابعة:', 
          components: [nextButton], 
          ephemeral: true 
        });
      }

      if (interaction.customId === 'modal_add_option_part2') {
        const adminRole = interaction.fields.getTextInputValue('option_admin_role');
        const category = interaction.fields.getTextInputValue('option_category');
        const optionData = tempData.get(`option_data_${interaction.user.id}`);
        const sectionId = tempData.get(`section_${interaction.user.id}`);
        const isEditing = tempData.get(`editing_existing_option_${interaction.user.id}`);
        const optionIndex = tempData.get(`option_index_${interaction.user.id}`);

        if (!optionData || !sectionId) {
          return interaction.reply({ content: '❌ حدث خطأ. حاول مرة أخرى.', ephemeral: true });
        }

        optionData.adminRole = adminRole || null;
        optionData.categoryId = category || null;

        if (isEditing && optionIndex !== undefined) {
          sectionManager.updateOption(sectionId, optionIndex, optionData);
          await interaction.reply({ content: `✅ تم تعديل الخيار **${optionData.name}** بنجاح!`, ephemeral: true });
        } else {
          sectionManager.addOption(sectionId, optionData);
          await interaction.reply({ content: `✅ تم إضافة الخيار **${optionData.name}** بنجاح!`, ephemeral: true });
        }

        tempData.delete(`option_data_${interaction.user.id}`);
        tempData.delete(`editing_existing_option_${interaction.user.id}`);
      }

      if (interaction.customId === 'modal_edit_embed_title') {
        const title = interaction.fields.getTextInputValue('embed_title');
        const sectionId = tempData.get(`section_${interaction.user.id}`);
        const embedType = tempData.get(`embed_type_${interaction.user.id}`);

        if (embedType === 'ticket') {
          const optionIndex = tempData.get(`option_index_${interaction.user.id}`);
          sectionManager.updateOptionTicketEmbed(sectionId, optionIndex, { title });
        } else if (embedType === 'section') {
          sectionManager.updateSectionEmbed(sectionId, { title });
        }

        await interaction.reply({ content: '✅ تم تحديث العنوان.', ephemeral: true });
      }

      if (interaction.customId === 'modal_edit_embed_description') {
        const description = interaction.fields.getTextInputValue('embed_description');
        const sectionId = tempData.get(`section_${interaction.user.id}`);
        const embedType = tempData.get(`embed_type_${interaction.user.id}`);

        if (embedType === 'ticket') {
          const optionIndex = tempData.get(`option_index_${interaction.user.id}`);
          sectionManager.updateOptionTicketEmbed(sectionId, optionIndex, { description });
        } else if (embedType === 'section') {
          sectionManager.updateSectionEmbed(sectionId, { description });
        }

        await interaction.reply({ content: '✅ تم تحديث الوصف.', ephemeral: true });
      }

      if (interaction.customId === 'modal_edit_embed_images') {
        const thumbnail = interaction.fields.getTextInputValue('embed_thumbnail');
        const image = interaction.fields.getTextInputValue('embed_image');
        const sectionId = tempData.get(`section_${interaction.user.id}`);
        const embedType = tempData.get(`embed_type_${interaction.user.id}`);

        if (embedType === 'ticket') {
          const optionIndex = tempData.get(`option_index_${interaction.user.id}`);
          sectionManager.updateOptionTicketEmbed(sectionId, optionIndex, { 
            thumbnail: thumbnail || null, 
            image: image || null 
          });
        } else if (embedType === 'section') {
          sectionManager.updateSectionEmbed(sectionId, { 
            thumbnail: thumbnail || null, 
            image: image || null 
          });
        }

        await interaction.reply({ content: '✅ تم تحديث الصور.', ephemeral: true });
      }

      if (interaction.customId === 'modal_edit_embed_footer') {
        const text = interaction.fields.getTextInputValue('embed_footer_text');
        const icon = interaction.fields.getTextInputValue('embed_footer_icon');
        const sectionId = tempData.get(`section_${interaction.user.id}`);
        const embedType = tempData.get(`embed_type_${interaction.user.id}`);

        if (embedType === 'ticket') {
          const optionIndex = tempData.get(`option_index_${interaction.user.id}`);
          sectionManager.updateOptionTicketEmbed(sectionId, optionIndex, { 
            footer: { text: text || '', icon: icon || null } 
          });
        } else if (embedType === 'section') {
          sectionManager.updateSectionEmbed(sectionId, { 
            footer: { text: text || '', icon: icon || null } 
          });
        }

        await interaction.reply({ content: '✅ تم تحديث التذييل.', ephemeral: true });
      }

      if (interaction.customId === 'modal_edit_embed_color') {
        const color = interaction.fields.getTextInputValue('embed_color');
        const sectionId = tempData.get(`section_${interaction.user.id}`);
        const embedType = tempData.get(`embed_type_${interaction.user.id}`);

        if (embedType === 'ticket') {
          const optionIndex = tempData.get(`option_index_${interaction.user.id}`);
          sectionManager.updateOptionTicketEmbed(sectionId, optionIndex, { color });
        } else if (embedType === 'section') {
          sectionManager.updateSectionEmbed(sectionId, { color });
        }

        await interaction.reply({ content: '✅ تم تحديث اللون.', ephemeral: true });
      }

      if (interaction.customId === 'modal_close_reason') {
        const reason = interaction.fields.getTextInputValue('close_reason');
        const ticketData = ticketManager.getTicketByChannelId(interaction.channel.id);

        if (!ticketData) {
          return interaction.reply({ content: '❌ لم يتم العثور على التذكرة.', ephemeral: true });
        }

        const [ticketId, ticket] = ticketData;
        const section = sectionManager.getSection(Object.keys(sectionManager.getAllSections()).find(id => {
          const s = sectionManager.getSection(id);
          return s.name === ticket.sectionName;
        }));

        await interaction.reply({ content: '✅ جاري إغلاق التذكرة...', ephemeral: true });
        await ticketManager.closeTicket(
          ticketId, 
          reason, 
          interaction.user.tag, 
          interaction.channel, 
          section?.logChannelId, 
          interaction.guild
        );
      }

      if (interaction.customId === 'modal_ratings_settings') {
        const channelId = interaction.fields.getTextInputValue('ratings_channel_id');
        const enabledText = interaction.fields.getTextInputValue('ratings_enabled').toLowerCase();

        const enabled = enabledText === 'تفعيل' || enabledText === 'enable' || enabledText === 'true';

        settingsManager.updateRatingsSettings(channelId, enabled);

        const fs = require('fs');
        const path = require('path');
        const configPath = path.join(__dirname, '../config.js');
        let configContent = fs.readFileSync(configPath, 'utf8');
        
        const newChannelId = enabled ? channelId : '';
        configContent = configContent.replace(
          /ratingsChannelId:\s*['"][^'"]*['"]/,
          `ratingsChannelId: '${newChannelId}'`
        );
        
        fs.writeFileSync(configPath, configContent);
        

        delete require.cache[require.resolve('../config.js')];
        const updatedConfig = require('../config.js');
        Object.assign(config, updatedConfig);

        const statusText = enabled ? 'مفعل ✅' : 'معطل ❌';
        await interaction.reply({ 
          content: `✅ تم تحديث إعدادات التقييمات!\n📺 القناة: ${enabled ? `<#${channelId}>` : 'غير محدد'}\n📊 الحالة: ${statusText}`, 
          ephemeral: true 
        });
      }

      if (interaction.customId === 'modal_rating_message') {
        const message = interaction.fields.getTextInputValue('rating_message') || 'لا توجد رسالة';
        const stars = tempData.get(`rating_stars_${interaction.user.id}`);
        const ticketId = tempData.get(`rating_ticket_${interaction.user.id}`);

        if (!stars) {
          return interaction.reply({ content: '❌ حدث خطأ. حاول مرة أخرى.', ephemeral: true });
        }

        const ratingsChannelId = config.ratingsChannelId;

        if (!ratingsChannelId) {
          return interaction.reply({ 
            content: '❌ قناة التقييمات غير مفعلة. قم بتفعيلها من /tpanel', 
            ephemeral: true 
          });
        }

        const ticketManager = require('../utils/ticketManager');
        const ticket = ticketManager.getTicket(ticketId);

        try {
          const guildId = config.guildId;
          let guild = interaction.client.guilds.cache.get(guildId);

          if (!guild) {
            try {
              guild = await interaction.client.guilds.fetch(guildId);
            } catch (error) {
              console.error('Failed to fetch guild:', guildId, error);
              return interaction.reply({ content: '❌ لم يتم العثور على السيرفر.', ephemeral: true });
            }
          }

          let ratingsChannel = guild.channels.cache.get(ratingsChannelId);
          if (!ratingsChannel) {
            try {
              ratingsChannel = await guild.channels.fetch(ratingsChannelId);
            } catch (error) {
              console.error('Failed to fetch ratings channel:', ratingsChannelId, error);
              return interaction.reply({ 
                content: '❌ لم يتم العثور على قناة التقييمات. تأكد من ID القناة في /tpanel', 
                ephemeral: true 
              });
            }
          }

          if (!ratingsChannel) {
            return interaction.reply({ 
              content: '❌ قناة التقييمات غير موجودة. تأكد من ID القناة في /tpanel', 
              ephemeral: true 
            });
          }

          const starsDisplay = '⭐'.repeat(stars) + '☆'.repeat(5 - stars);

          const ratingEmbed = new EmbedBuilder()
            .setTitle('📊 تقييم جديد')
            .addFields(
              { name: 'العضو', value: `${interaction.user.tag}`, inline: true },
              { name: 'النجوم', value: `${starsDisplay} (${stars}/5)`, inline: true },
              { name: 'الرسالة', value: message }
            )
            .setColor(stars >= 4 ? '#00FF00' : stars >= 3 ? '#FFFF00' : '#FF0000')
            .setTimestamp()
            .setThumbnail(interaction.user.displayAvatarURL());

          if (ticket) {
            ratingEmbed.addFields(
              { name: '📋 القسم', value: ticket.sectionName, inline: true },
              { name: '🎫 النوع', value: ticket.optionName, inline: true }
            );
          }

          await ratingsChannel.send({ embeds: [ratingEmbed] });

          tempData.delete(`rating_stars_${interaction.user.id}`);
          tempData.delete(`rating_ticket_${interaction.user.id}`);
          tempData.delete(`rating_channel_${interaction.user.id}`);

          await interaction.reply({ content: '✅ شكراً لك! تم إرسال تقييمك بنجاح.', ephemeral: true });
        } catch (error) {
          console.error('Rating error:', error);
          await interaction.reply({ content: '❌ حدث خطأ أثناء إرسال التقييم.', ephemeral: true });
        }
      }
    }

    if (interaction.isButton() && interaction.customId.startsWith('ticket_create_')) {
      const customId = interaction.customId;
      const prefix = 'ticket_create_';
      const valueWithoutPrefix = customId.substring(prefix.length);
      const lastUnderscoreIndex = valueWithoutPrefix.lastIndexOf('_');
      const sectionId = valueWithoutPrefix.substring(0, lastUnderscoreIndex);
      const optionIndex = parseInt(valueWithoutPrefix.substring(lastUnderscoreIndex + 1));

      const section = sectionManager.getSection(sectionId);

      if (!section) {
        console.log('Section not found:', sectionId);
        return interaction.reply({ content: '❌ حدث خطأ. القسم غير موجود.', ephemeral: true });
      }

      if (!section.options || section.options.length === 0) {
        console.log('No options in section:', sectionId);
        return interaction.reply({ content: '❌ حدث خطأ. لا توجد خيارات في القسم.', ephemeral: true });
      }

      if (isNaN(optionIndex) || optionIndex < 0 || optionIndex >= section.options.length) {
        console.log('Invalid option index:', optionIndex, 'Available options:', section.options.length);
        return interaction.reply({ content: '❌ حدث خطأ. الخيار غير موجود.', ephemeral: true });
      }

      const option = section.options[optionIndex];

      await interaction.deferReply({ ephemeral: true });
      const result = await ticketManager.createTicket(interaction.guild, interaction.user, section, option, section.logChannelId);

      if (result.error) {
        return interaction.editReply({ content: `❌ ${result.error}` });
      }

      await interaction.editReply({ content: `✅ تم إنشاء تذكرتك ${result.channel}` });
    }

    if (interaction.isButton() && interaction.customId.startsWith('ticket_reopen_')) {
      if (!hasAdminPermission) {
        return interaction.reply({ content: '❌ ليس لديك صلاحية لهذا الإجراء.', ephemeral: true });
      }

      const ticketId = interaction.customId.replace('ticket_reopen_', '');
      await interaction.deferUpdate();

      const result = await ticketManager.reopenTicket(ticketId, interaction.guild);

      if (result.error) {
        await interaction.followUp({ content: `❌ ${result.error}`, ephemeral: true });
      } else {
        await interaction.editReply({ content: '✅ تم إعادة فتح التذكرة بنجاح!', components: [], embeds: [] });
      }
    }

    if (interaction.isButton() && interaction.customId.startsWith('ticket_delete_')) {
      if (!hasAdminPermission) {
        return interaction.reply({ content: '❌ ليس لديك صلاحية لهذا الإجراء.', ephemeral: true });
      }

      const ticketId = interaction.customId.replace('ticket_delete_', '');
      await interaction.reply({ content: '🗑️ جاري حذف التذكرة...', ephemeral: true });

      const result = await ticketManager.deleteTicket(ticketId, interaction.guild);

      if (result.error) {
        await interaction.editReply({ content: `❌ ${result.error}` });
      }

    }
  }
};