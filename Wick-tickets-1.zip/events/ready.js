
const { ActivityType } = require('discord.js');

module.exports = {
  name: 'ready',
  once: true,
  execute(client) {
    console.log(`
.------..------..------..------.        .------..------..------..------..------..------.
|W.--. ||I.--. ||C.--. ||K.--. | .-.    |S.--. ||T.--. ||U.--. ||D.--. ||I.--. ||O.--. |
| :/\\: || (\\/) || :/\\: || :/\\: |((5))   | :/\\: || :/\\: || (\\/) || :/\\: || (\\/) || :/\\: |
| :\\/: || :\\/: || :\\/: || :\\/: | '-.-.  | :\\/: || (__) || :\\/: || (__) || :\\/: || :\\/: |
| '--'W|| '--'I|| '--'C|| '--'K|  ((1)) | '--'S|| '--'T|| '--'U|| '--'D|| '--'I|| '--'O|
\`------'\`------'\`------'\`------'   '-'  \`------'\`------'\`------'\`------'\`------'\`------'

Bot logged in as ${client.user.tag} | 📊 Serving ${client.guilds.cache.size} servers
`);
    client.user.setActivity('Wicks Ticket', { type: ActivityType.Watching });
  }
};
