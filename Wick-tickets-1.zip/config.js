
module.exports = {
  token: 'MTE5NjYzOTAwMjQ1NTk4MjE5Mg.G5fOUZ.Ob-q9c9J821OtWbysL78nPClVI9Q8DGK6K3eE4',
  clientId: 'botid',
  guildId: '1368976062821699658',
  ownerId: '1097095130965614703',
  adminRoles: ['adminrole'],
  ratingsChannelId: 'ratechannel',
  emojis: {
    add: '➕',
    edit: '✏️',
    notes: '📝',
    ticket: '🎫',
    delete: '🗑️',
    deleteOption: '❌',
    deleteAll: '🚫',
    prevPage: '◀️',
    nextPage: '▶️',
    next: '➡️',
    claim: '✋',
    settings: '⚙️',
    unlock: '🔓',
    lock: '🔒',
    add_user: '➕',
    remove_user: '➖',
    reminder: '🔔',
    copy: '📋',
    stars: '⭐'
  }
};
