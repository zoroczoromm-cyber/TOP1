
const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const config = require('../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('tpanel')
    .setDescription('لوحة التحكم بنظام التذاكر'),
  
  async execute(interaction) {
    const hasPermission = interaction.user.id === config.ownerId || 
                         interaction.member?.roles.cache.some(role => config.adminRoles.includes(role.id));
    
    if (!hasPermission) {
      return interaction.reply({ content: '❌ ليس لديك صلاحية لاستخدام هذا الأمر.', ephemeral: true });
    }

    const embed = new EmbedBuilder()
      .setTitle('🎫 لوحة التحكم - نظام التذاكر')
      .setDescription('اختر أحد الخيارات التالية:')
      .setColor('#5865F2')
      .setTimestamp();

    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('tpanel_add_section')
          .setLabel('اضافة')
          .setStyle(ButtonStyle.Success)
          .setEmoji(config.emojis.add),
        new ButtonBuilder()
          .setCustomId('tpanel_edit_section')
          .setLabel('تعديل')
          .setStyle(ButtonStyle.Primary)
          .setEmoji(config.emojis.edit),
        new ButtonBuilder()
          .setCustomId('tpanel_ratings')
          .setLabel('التقييمات')
          .setStyle(ButtonStyle.Secondary)
          .setEmoji(config.emojis.stars)
      );

    await interaction.reply({ embeds: [embed], components: [row], ephemeral: true });
  }
};
