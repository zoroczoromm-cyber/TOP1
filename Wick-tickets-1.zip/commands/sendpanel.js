
const { SlashCommandBuilder } = require('discord.js');
const config = require('../config');
const { createSectionSelectMenu } = require('../components/selects');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('sendpanel')
    .setDescription('إرسال لوحة التذاكر إلى قناة محددة')
    .addChannelOption(option =>
      option.setName('channel')
        .setDescription('القناة المراد إرسال اللوحة إليها')
        .setRequired(true)
    ),
  
  async execute(interaction) {
    const hasPermission = interaction.user.id === config.ownerId || 
                         interaction.member?.roles.cache.some(role => config.adminRoles.includes(role.id));
    
    if (!hasPermission) {
      return interaction.reply({ content: '❌ ليس لديك صلاحية لاستخدام هذا الأمر.', ephemeral: true });
    }

    const channel = interaction.options.getChannel('channel');
    
    const { tempData } = require('../events/interactionCreate');
    if (!global.sendpanelTempData) global.sendpanelTempData = new Map();
    global.sendpanelTempData.set(`sendpanel_channel_${interaction.user.id}`, channel.id);
    
    const { selectRow } = createSectionSelectMenu(0, 'sendpanel_section_select');
    
    await interaction.reply({ 
      content: 'اختر القسم الذي تريد إرساله:', 
      components: [selectRow], 
      ephemeral: true 
    });
  }
};
