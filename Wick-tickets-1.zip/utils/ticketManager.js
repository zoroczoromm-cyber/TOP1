const fs = require('fs');
const path = require('path');
const { PermissionFlagsBits, ChannelType, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder } = require('discord.js');
const discordTranscripts = require('discord-html-transcripts');
const settingsManager = require('./settingsManager');
const config = require('../config');

const ticketsPath = path.join(__dirname, '../database/tickets.json');
const userTicketsPath = path.join(__dirname, '../database/userTickets.json');

function readTickets() {
  return JSON.parse(fs.readFileSync(ticketsPath, 'utf8'));
}

function writeTickets(data) {
  fs.writeFileSync(ticketsPath, JSON.stringify(data, null, 2));
}

function readUserTickets() {
  return JSON.parse(fs.readFileSync(userTicketsPath, 'utf8'));
}

function writeUserTickets(data) {
  fs.writeFileSync(userTicketsPath, JSON.stringify(data, null, 2));
}

module.exports = {
  async createTicket(guild, user, section, option, logChannelId = null) {
    const userTickets = readUserTickets();
    const userKey = `${user.id}_${section.name}_${option.name}`;

    if (!userTickets[userKey]) {
      userTickets[userKey] = [];
    }

    if (option.maxTickets && userTickets[userKey].length >= option.maxTickets) {
      return { error: 'لقد وصلت إلى الحد الأقصى من التذاكر المسموح بها.' };
    }

    const tickets = readTickets();
    const ticketCount = Object.keys(tickets).length + 1;

    let channelName = option.namingPattern || 'ticket-{num}';
    channelName = channelName.replace('{num}', ticketCount).replace('{user}', user.username);

    const permissionOverwrites = [
      {
        id: guild.id,
        deny: [PermissionFlagsBits.ViewChannel]
      },
      {
        id: user.id,
        allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory]
      }
    ];

    if (option.adminRole) {
      permissionOverwrites.push({
        id: option.adminRole,
        allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory]
      });
    }

    const channelData = {
      name: channelName,
      type: ChannelType.GuildText,
      permissionOverwrites
    };

    if (option.categoryId) {
      channelData.parent = option.categoryId;
    }

    const channel = await guild.channels.create(channelData);

    const ticketEmbed = option.ticketEmbed || {};
    const embed = new EmbedBuilder()
      .setTitle(ticketEmbed.title || option.name)
      .setDescription(ticketEmbed.description || `تذكرة جديدة من ${user}`)
      .setColor(ticketEmbed.color || '#5865F2')
      .setTimestamp();

    if (ticketEmbed.thumbnail) embed.setThumbnail(ticketEmbed.thumbnail);
    if (ticketEmbed.image) embed.setImage(ticketEmbed.image);
    if (ticketEmbed.footer?.text) {
      embed.setFooter({
        text: ticketEmbed.footer.text,
        iconURL: ticketEmbed.footer.icon || undefined
      });
    }

    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('ticket_claim')
          .setLabel('استلام')
          .setStyle(ButtonStyle.Success)
          .setEmoji(config.emojis.claim),
        new ButtonBuilder()
          .setCustomId('ticket_options')
          .setLabel('خيارات التكت')
          .setStyle(ButtonStyle.Primary)
          .setEmoji(config.emojis.settings)
      );

    let mentionContent = `${user}`;
    if (option.adminRole) {
      mentionContent += ` | <@&${option.adminRole}>`;
    }
    await channel.send({ content: mentionContent, embeds: [embed], components: [row] });

    const ticketId = `ticket_${Date.now()}_${user.id}`;
    tickets[ticketId] = {
      channelId: channel.id,
      userId: user.id,
      sectionName: section.name,
      optionName: option.name,
      claimed: false,
      claimedBy: null,
      createdAt: Date.now(),
      additionalUsers: []
    };
    writeTickets(tickets);

    userTickets[userKey].push(ticketId);
    writeUserTickets(userTickets);

    if (logChannelId) {
      const logChannel = guild.channels.cache.get(logChannelId);
      if (logChannel) {
        const logEmbed = new EmbedBuilder()
          .setTitle('🎫 تم إنشاء تذكرة جديدة')
          .addFields(
            { name: 'المستخدم', value: `${user.tag} (${user.id})`, inline: true },
            { name: 'النوع', value: `${section.name} - ${option.name}`, inline: true },
            { name: 'القناة', value: `${channel}`, inline: true },
            { name: 'وقت الإنشاء', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: false }
          )
          .setColor('#00FF00')
          .setTimestamp();

        await logChannel.send({ embeds: [logEmbed] }).catch(console.error);
      }
    }

    return { success: true, channel, ticketId };
  },

  getTicket(ticketId) {
    const tickets = readTickets();
    return tickets[ticketId];
  },

  getTicketByChannelId(channelId) {
    const tickets = readTickets();
    return Object.entries(tickets).find(([_, ticket]) => ticket.channelId === channelId);
  },

  updateTicket(ticketId, updates) {
    const tickets = readTickets();
    if (tickets[ticketId]) {
      tickets[ticketId] = { ...tickets[ticketId], ...updates };
      writeTickets(tickets);
      return tickets[ticketId];
    }
    return null;
  },

  async closeTicket(ticketId, reason, closedBy, channel, logChannelId, guild) {
    const tickets = readTickets();
    const ticket = tickets[ticketId];

    if (!ticket) return null;

    const user = await guild.members.fetch(ticket.userId).catch(() => null);
    const transcriptNumber = settingsManager.getNextTranscriptNumber();

    const transcriptFilename = `${ticket.sectionName}-${ticket.optionName}-${user ? user.user.username : ticket.userId}-${transcriptNumber}.html`
      .replace(/\s+/g, '-')
      .replace(/[^a-zA-Z0-9\u0600-\u06FF\-_.]/g, '');

    const transcript = await discordTranscripts.createTranscript(channel, {
      limit: -1,
      returnType: 'attachment',
      filename: transcriptFilename,
      saveImages: true,
      poweredBy: false
    });

    if (logChannelId) {
      const logChannel = guild.channels.cache.get(logChannelId);
      if (logChannel) {
        const logEmbed = new EmbedBuilder()
          .setTitle('📋 سجل إغلاق تذكرة')
          .addFields(
            { name: 'المستخدم', value: user ? `${user.user.tag} (${user.id})` : ticket.userId, inline: true },
            { name: 'النوع', value: `${ticket.sectionName} - ${ticket.optionName}`, inline: true },
            { name: 'تم الإغلاق بواسطة', value: closedBy, inline: true },
            { name: 'سبب الإغلاق', value: reason || 'لم يتم تحديد سبب' }
          )
          .setColor('#FF0000')
          .setTimestamp();

        if (ticket.additionalUsers && ticket.additionalUsers.length > 0) {
          const usersList = ticket.additionalUsers.map(uid => `<@${uid}>`).join(', ');
          logEmbed.addFields({ name: 'المستخدمون الإضافيون', value: usersList });
        }

        await logChannel.send({ embeds: [logEmbed], files: [transcript] });
      }
    }

    const members = await channel.members;
    for (const [memberId, member] of members) {
      if (!member.user.bot) {
        await channel.permissionOverwrites.delete(member).catch(console.error);
      }
    }

    const closeEmbed = new EmbedBuilder()
      .setTitle('🔒 تم إغلاق التذكرة')
      .setDescription(`**السبب:** ${reason || 'لم يتم تحديد سبب'}\n**تم الإغلاق بواسطة:** ${closedBy}`)
      .addFields(
        { name: 'المستخدم', value: user ? `${user.user.tag}` : ticket.userId, inline: true },
        { name: 'النوع', value: `${ticket.sectionName} - ${ticket.optionName}`, inline: true },
        { name: 'رقم النسخة', value: `#${transcriptNumber}`, inline: true }
      )
      .setColor('#FF0000')
      .setTimestamp();

    const actionRow = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId(`ticket_reopen_${ticketId}`)
          .setLabel('فتح')
          .setStyle(ButtonStyle.Success)
          .setEmoji(config.emojis.unlock),
        new ButtonBuilder()
          .setCustomId(`ticket_delete_${ticketId}`)
          .setLabel('حذف')
          .setStyle(ButtonStyle.Danger)
          .setEmoji(config.emojis.delete)
      );

    await channel.send({ embeds: [closeEmbed], components: [actionRow] });

    tickets[ticketId].closed = true;
    tickets[ticketId].closedAt = Date.now();
    tickets[ticketId].closedBy = closedBy;
    tickets[ticketId].closeReason = reason;
    tickets[ticketId].transcriptFilename = transcriptFilename;
    tickets[ticketId].transcriptNumber = transcriptNumber;
    tickets[ticketId].guildId = guild.id;
    tickets[ticketId].channelUrl = channel.url;
    writeTickets(tickets);

    return transcript;
  },

  async sendTranscript(channel, requester, guild) {
    const ticketData = this.getTicketByChannelId(channel.id);
    if (!ticketData) {
      return { error: 'لم يتم العثور على التذكرة.' };
    }

    const [ticketId, ticket] = ticketData;
    const transcriptNumber = settingsManager.getNextTranscriptNumber();

    const ticketOwner = await guild.members.fetch(ticket.userId).catch(() => null);
    const ownerName = ticketOwner ? ticketOwner.user.username : ticket.userId;

    const transcriptFilename = `${ticket.sectionName}-${ticket.optionName}-${ownerName}-${transcriptNumber}.html`
      .replace(/\s+/g, '-')
      .replace(/[^a-zA-Z0-9\u0600-\u06FF\-_.]/g, '');

    const transcript = await discordTranscripts.createTranscript(channel, {
      limit: -1,
      returnType: 'attachment',
      filename: transcriptFilename,
      saveImages: true,
      poweredBy: false
    });

    try {
      const ownerMention = ticketOwner ? ticketOwner.user.tag : ticket.userId;
      await requester.send({
        content: `نسخة من تذكرة ${ownerMention} في سيرفر **${guild.name}**\n📋 القسم: ${ticket.sectionName}\n🎫 النوع: ${ticket.optionName}\n🔢 الرقم: #${transcriptNumber}\n🔗 الرابط: ${channel.url}`,
        files: [transcript]
      });
      return { success: true };
    } catch (error) {
      console.error('Failed to send transcript:', error);
      return { error: 'فشل إرسال النسخة. تأكد من أن رسائلك الخاصة مفتوحة.' };
    }
  },

  async reopenTicket(ticketId, guild) {
    const tickets = readTickets();
    const ticket = tickets[ticketId];

    if (!ticket) return { error: 'التذكرة غير موجودة' };

    const channel = guild.channels.cache.get(ticket.channelId);
    if (!channel) return { error: 'القناة غير موجودة' };

    const user = await guild.members.fetch(ticket.userId).catch(() => null);
    if (user) {
      await channel.permissionOverwrites.create(user, {
        ViewChannel: true,
        SendMessages: true,
        ReadMessageHistory: true
      });
    }

    if (ticket.additionalUsers && ticket.additionalUsers.length > 0) {
      for (const userId of ticket.additionalUsers) {
        const member = await guild.members.fetch(userId).catch(() => null);
        if (member) {
          await channel.permissionOverwrites.create(member, {
            ViewChannel: true,
            SendMessages: true,
            ReadMessageHistory: true
          });
        }
      }
    }

    delete ticket.closed;
    delete ticket.closedAt;
    delete ticket.closedBy;
    delete ticket.closeReason;
    writeTickets(tickets);

    const reopenEmbed = new EmbedBuilder()
      .setTitle('🔓 تم إعادة فتح التذكرة')
      .setDescription(`تم إعادة فتح التذكرة بنجاح`)
      .setColor('#00FF00')
      .setTimestamp();

    await channel.send({ embeds: [reopenEmbed] });

    return { success: true, channel };
  },

  async deleteTicket(ticketId, guild) {
    const tickets = readTickets();
    const ticket = tickets[ticketId];

    if (!ticket) return { error: 'التذكرة غير موجودة' };

    let channel = null;
    try {
      channel = await guild.channels.fetch(ticket.channelId).catch(() => null);
    } catch (error) {
      console.error('Channel already deleted or not found:', error);
    }

    if (ticket.closed && ticket.transcriptFilename && channel) {
      const user = await guild.members.fetch(ticket.userId).catch(() => null);

      if (user) {
        try {
          const transcript = await discordTranscripts.createTranscript(channel, {
            limit: -1,
            returnType: 'attachment',
            filename: ticket.transcriptFilename,
            saveImages: true,
            poweredBy: false
          });

          const ratingsEnabled = settingsManager.isRatingsEnabled();
          const config = require('../config');

          const closeMessage = `تم حذف تذكرتك في **${guild.name}**\nالسبب: ${ticket.closeReason || 'لم يتم تحديد سبب'}\n📋 القسم: ${ticket.sectionName}\n🎫 النوع: ${ticket.optionName}\n🔢 الرقم: #${ticket.transcriptNumber}`;

          if (ratingsEnabled && config.ratingsChannelId) {
            const ratingSelect = new StringSelectMenuBuilder()
              .setCustomId(`rating_stars_${ticketId}`)
              .setPlaceholder('اختر عدد النجوم')
              .addOptions([
                { label: '⭐ نجمة واحدة', value: '1', emoji: '1️⃣' },
                { label: '⭐⭐ نجمتين', value: '2', emoji: '2️⃣' },
                { label: '⭐⭐⭐ ثلاث نجوم', value: '3', emoji: '3️⃣' },
                { label: '⭐⭐⭐⭐ أربع نجوم', value: '4', emoji: '4️⃣' },
                { label: '⭐⭐⭐⭐⭐ خمس نجوم', value: '5', emoji: '5️⃣' }
              ]);

            const ratingRow = new ActionRowBuilder().addComponents(ratingSelect);

            await user.send({
              content: `${closeMessage}\n\n⭐ **يرجى تقييم تجربتك:**`,
              files: [transcript],
              components: [ratingRow]
            });
          } else {
            await user.send({
              content: closeMessage,
              files: [transcript]
            });
          }
        } catch (error) {
          console.error('Failed to send DM to user:', error);
        }
      }
    }

    const userTickets = readUserTickets();
    const userKey = `${ticket.userId}_${ticket.sectionName}_${ticket.optionName}`;
    if (userTickets[userKey]) {
      userTickets[userKey] = userTickets[userKey].filter(id => id !== ticketId);
      writeUserTickets(userTickets);
    }

    delete tickets[ticketId];
    writeTickets(tickets);

    if (channel) {
      await channel.delete().catch(console.error);
    }

    return { success: true };
  },

  async sendRatingRequest(user, ticketId, guild) {
    const config = require('../config');
    const { tempData } = require('../events/interactionCreate');
    const ratingsChannel = await guild.channels.fetch(config.ratingsChannelId).catch(() => null);

    if (!ratingsChannel) {
      console.error(`Ratings channel not found: ${config.ratingsChannelId}`);
      return;
    }

    const ticket = this.getTicket(ticketId);
    if (!ticket) {
      console.error(`Ticket not found for rating request: ${ticketId}`);
      return;
    }

    const ticketOwner = await guild.members.fetch(ticket.userId).catch(() => null);
    const ownerName = ticketOwner ? ticketOwner.user.username : ticket.userId;

    const embed = new EmbedBuilder()
      .setTitle('⭐ تقييم تجربة التذكرة')
      .setDescription(`يرجى تقييم تجربتك مع التذكرة التي تم إغلاقها مؤخرًا.\n\n**المستخدم:** ${ownerName}\n**النوع:** ${ticket.sectionName} - ${ticket.optionName}`)
      .setColor('#FFFF00')
      .setTimestamp();

    const starsSelect = new StringSelectMenuBuilder()
      .setCustomId(`rating_stars_${ticketId}`)
      .setPlaceholder('اختر عدد النجوم')
      .addOptions([
        { label: '⭐ نجمة واحدة', value: '1', emoji: '1️⃣' },
        { label: '⭐⭐ نجمتين', value: '2', emoji: '2️⃣' },
        { label: '⭐⭐⭐ ثلاث نجوم', value: '3', emoji: '3️⃣' },
        { label: '⭐⭐⭐⭐ أربع نجوم', value: '4', emoji: '4️⃣' },
        { label: '⭐⭐⭐⭐⭐ خمس نجوم', value: '5', emoji: '5️⃣' }
      ]);

    const row = new ActionRowBuilder().addComponents(starsSelect);

    tempData.set(`rating_guild_${user.id}`, guild.id);
    tempData.set(`rating_channel_${user.id}`, config.ratingsChannelId);

    await ratingsChannel.send({ embeds: [embed], components: [row] });
  }
};