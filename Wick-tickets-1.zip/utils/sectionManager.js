const fs = require('fs');
const path = require('path');

const sectionsPath = path.join(__dirname, '../database/sections.json');

function readSections() {
  return JSON.parse(fs.readFileSync(sectionsPath, 'utf8'));
}

function writeSections(data) {
  fs.writeFileSync(sectionsPath, JSON.stringify(data, null, 2));
}

module.exports = {
  createSection(sectionId, name, type, logChannelId) {
    const sections = readSections();
    sections[sectionId] = {
      name,
      type,
      logChannelId,
      options: [],
      embed: {
        title: name,
        description: '',
        color: '#5865F2',
        thumbnail: null,
        image: null,
        footer: { text: '', icon: null }
      }
    };
    writeSections(sections);
    return sections[sectionId];
  },

  getSection(sectionId) {
    const sections = readSections();
    return sections[sectionId];
  },

  getAllSections() {
    return readSections();
  },

  updateSection(sectionId, updates) {
    const sections = readSections();
    if (sections[sectionId]) {
      sections[sectionId] = { ...sections[sectionId], ...updates };
      writeSections(sections);
      return sections[sectionId];
    }
    return null;
  },

  deleteSection(sectionId) {
    const sections = readSections();
    delete sections[sectionId];
    writeSections(sections);
  },

  addOption(sectionId, option) {
    const sections = readSections();
    if (sections[sectionId]) {
      sections[sectionId].options.push(option);
      writeSections(sections);
      return option;
    }
    return null;
  },

  updateOption(sectionId, optionIndex, updates) {
    const sections = readSections();
    if (sections[sectionId] && sections[sectionId].options[optionIndex]) {
      sections[sectionId].options[optionIndex] = { 
        ...sections[sectionId].options[optionIndex], 
        ...updates 
      };
      writeSections(sections);
      return sections[sectionId].options[optionIndex];
    }
    return null;
  },

  deleteOption(sectionId, optionIndex) {
    const sections = readSections();
    if (sections[sectionId]) {
      sections[sectionId].options.splice(optionIndex, 1);
      writeSections(sections);
    }
  },

  updateSectionEmbed(sectionId, embedData) {
    const sections = readSections();
    if (sections[sectionId]) {
      sections[sectionId].embed = { ...sections[sectionId].embed, ...embedData };
      writeSections(sections);
      return sections[sectionId];
    }
    return null;
  },

  updateOptionTicketEmbed(sectionId, optionIndex, embedData) {
    const sections = readSections();
    if (sections[sectionId] && sections[sectionId].options[optionIndex]) {
      if (!sections[sectionId].options[optionIndex].ticketEmbed) {
        sections[sectionId].options[optionIndex].ticketEmbed = {};
      }
      sections[sectionId].options[optionIndex].ticketEmbed = {
        ...sections[sectionId].options[optionIndex].ticketEmbed,
        ...embedData
      };
      writeSections(sections);
      return sections[sectionId].options[optionIndex];
    }
    return null;
  }
};
