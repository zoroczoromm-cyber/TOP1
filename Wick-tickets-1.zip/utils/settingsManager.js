const fs = require('fs');
const path = require('path');

const settingsPath = path.join(__dirname, '../database/settings.json');

function readSettings() {
  try {
    return JSON.parse(fs.readFileSync(settingsPath, 'utf8'));
  } catch {
    return { ratings: { enabled: false, channelId: null } };
  }
}

function writeSettings(data) {
  fs.writeFileSync(settingsPath, JSON.stringify(data, null, 2));
}

module.exports = {
  getRatingsSettings() {
    const settings = readSettings();
    return settings.ratings || { enabled: false, channelId: null };
  },

  updateRatingsSettings(channelId, enabled) {
    const settings = readSettings();
    settings.ratings = {
      enabled: enabled,
      channelId: channelId
    };
    writeSettings(settings);
    return settings.ratings;
  },

  isRatingsEnabled() {
    const settings = readSettings();
    return settings.ratings?.enabled || false;
  },

  getRatingsChannelId() {
    const settings = readSettings();
    return settings.ratings?.channelId || null;
  },

  getNextTranscriptNumber() {
    const settings = readSettings();
    const currentNumber = settings.transcriptCounter || 0;
    settings.transcriptCounter = currentNumber + 1;
    writeSettings(settings);
    return settings.transcriptCounter;
  }
};
