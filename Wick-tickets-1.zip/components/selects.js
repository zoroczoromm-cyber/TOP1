const { StringSelectMenuBuilder, ActionRowBuilder, UserSelectMenuBuilder } = require('discord.js');
const sectionManager = require('../utils/sectionManager');
const config = require('../config');

module.exports = {
  createSectionSelectMenu(page = 0, customId = 'section_select') {
    const sections = sectionManager.getAllSections();
    const sectionEntries = Object.entries(sections);

    const pageSize = 25;
    const startIdx = page * pageSize;
    const endIdx = startIdx + pageSize;
    let options = sectionEntries.slice(startIdx, endIdx).map(([id, section]) => ({
      label: section.name,
      value: id,
      description: `النوع: ${section.type === 'button' ? 'أزرار' : 'قائمة منسدلة'}`
    }));

    if (options.length === 0) {
      options.push({
        label: 'لا توجد أقسام',
        value: 'none'
      });
    }

    const select = new StringSelectMenuBuilder()
      .setCustomId(customId)
      .setPlaceholder('اختر قسماً')
      .addOptions(options);

    return { 
      selectRow: new ActionRowBuilder().addComponents(select), 
      totalPages: Math.ceil(sectionEntries.length / pageSize) || 1, 
      currentPage: page 
    };
  },

  createOptionSelectMenu(sectionId, customId = 'option_select') {
    const section = sectionManager.getSection(sectionId);
    if (!section || !section.options || section.options.length === 0) {
      const select = new StringSelectMenuBuilder()
        .setCustomId(customId)
        .setPlaceholder('لا توجد خيارات')
        .addOptions([{ label: 'لا توجد خيارات', value: 'none' }]);

      return new ActionRowBuilder().addComponents(select);
    }

    const options = section.options.map((option, index) => ({
      label: option.name,
      value: index.toString(),
      description: option.description || 'لا يوجد وصف',
      emoji: option.emoji || undefined
    }));

    const select = new StringSelectMenuBuilder()
      .setCustomId(customId)
      .setPlaceholder('اختر خياراً')
      .addOptions(options);

    return new ActionRowBuilder().addComponents(select);
  },

  createTicketOptionsSelectMenu() {
    return new ActionRowBuilder()
      .addComponents(
        new StringSelectMenuBuilder()
          .setCustomId('ticket_action_select')
          .setPlaceholder('اختر إجراءً')
          .addOptions([
            {
              label: 'إلغاء الاستلام',
              value: 'cancel_claim',
              emoji: config.emojis.unlock
            },
            {
              label: 'إغلاق مع سبب',
              value: 'close_reason',
              emoji: config.emojis.lock
            },
            {
              label: 'اضافة مستخدم',
              value: 'add_user',
              emoji: config.emojis.add_user
            },
            {
              label: 'حذف مستخدم',
              value: 'remove_user',
              emoji: config.emojis.remove_user
            },
            {
              label: 'تذكير العضو',
              value: 'member_reminder',
              emoji: config.emojis.reminder
            },
            {
              label: 'طلب نسخة',
              value: 'request_copy',
              emoji: config.emojis.copy
            }
          ])
      );
  },

  createUserSelectMenu() {
    return new ActionRowBuilder()
      .addComponents(
        new UserSelectMenuBuilder()
          .setCustomId('ticket_user_select')
          .setPlaceholder('اختر المستخدمين')
          .setMinValues(1)
          .setMaxValues(10)
      );
  },

  createRemoveUserSelectMenu(userIds) {
    return new ActionRowBuilder()
      .addComponents(
        new UserSelectMenuBuilder()
          .setCustomId('ticket_user_remove_select')
          .setPlaceholder('اختر المستخدمين للإزالة')
          .setMinValues(1)
          .setMaxValues(Math.min(userIds.length, 10))
      );
  },

  createDeleteOptionSelectMenu(sectionId) {
    const section = sectionManager.getSection(sectionId);
    if (!section || !section.options || section.options.length === 0) {
      const select = new StringSelectMenuBuilder()
        .setCustomId('delete_option_select')
        .setPlaceholder('لا توجد خيارات')
        .addOptions([{ label: 'لا توجد خيارات', value: 'none' }]);

      return new ActionRowBuilder().addComponents(select);
    }

    const options = section.options.map((option, index) => ({
      label: option.name,
      value: index.toString(),
      description: option.description || 'لا يوجد وصف',
      emoji: config.emojis.deleteOption
    }));

    const select = new StringSelectMenuBuilder()
      .setCustomId('delete_option_select')
      .setPlaceholder('اختر الخيار للحذف')
      .addOptions(options);

    return new ActionRowBuilder().addComponents(select);
  },

  createRatingSelectMenu() {
    const select = new StringSelectMenuBuilder()
      .setCustomId('rating_stars_select')
      .setPlaceholder('اختر تقييمك')
      .addOptions([
        { label: '⭐ نجمة واحدة', value: '1', emoji: '1️⃣' },
        { label: '⭐⭐ نجمتين', value: '2', emoji: '2️⃣' },
        { label: '⭐⭐⭐ ثلاث نجوم', value: '3', emoji: '3️⃣' },
        { label: '⭐⭐⭐⭐ أربع نجوم', value: '4', emoji: '4️⃣' },
        { label: '⭐⭐⭐⭐⭐ خمس نجوم', value: '5', emoji: '5️⃣' }
      ]);

    return new ActionRowBuilder().addComponents(select);
  }
};
