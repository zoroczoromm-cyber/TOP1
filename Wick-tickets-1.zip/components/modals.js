const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require('discord.js');

module.exports = {
  createAddSectionModal() {
    const modal = new ModalBuilder()
      .setCustomId('modal_add_section')
      .setTitle('إضافة قسم جديد');

    const nameInput = new TextInputBuilder()
      .setCustomId('section_name')
      .setLabel('اسم القسم')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);

    const typeInput = new TextInputBuilder()
      .setCustomId('section_type')
      .setLabel('نوع القسم (button أو select)')
      .setStyle(TextInputStyle.Short)
      .setRequired(true)
      .setPlaceholder('button or select');

    const logChannelInput = new TextInputBuilder()
      .setCustomId('log_channel_id')
      .setLabel('معرف قناة السجلات')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);

    modal.addComponents(
      new ActionRowBuilder().addComponents(nameInput),
      new ActionRowBuilder().addComponents(typeInput),
      new ActionRowBuilder().addComponents(logChannelInput)
    );

    return modal;
  },

  createAddOptionModal() {
    const modal = new ModalBuilder()
      .setCustomId('modal_add_option_part1')
      .setTitle('إضافة خيار جديد - الجزء 1');

    const nameInput = new TextInputBuilder()
      .setCustomId('option_name')
      .setLabel('اسم الخيار')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);

    const descInput = new TextInputBuilder()
      .setCustomId('option_description')
      .setLabel('وصف الخيار')
      .setStyle(TextInputStyle.Paragraph)
      .setRequired(false);

    const emojiInput = new TextInputBuilder()
      .setCustomId('option_emoji')
      .setLabel('الإيموجي')
      .setStyle(TextInputStyle.Short)
      .setRequired(false);

    const namingInput = new TextInputBuilder()
      .setCustomId('option_naming')
      .setLabel('نمط التسمية (ticket-{num}, {user})')
      .setStyle(TextInputStyle.Short)
      .setRequired(false)
      .setPlaceholder('ticket-{num}');

    const limitInput = new TextInputBuilder()
      .setCustomId('option_limit')
      .setLabel('الحد الأقصى للتذاكر لكل مستخدم')
      .setStyle(TextInputStyle.Short)
      .setRequired(false)
      .setPlaceholder('اتركه فارغاً لعدم وجود حد');

    modal.addComponents(
      new ActionRowBuilder().addComponents(nameInput),
      new ActionRowBuilder().addComponents(descInput),
      new ActionRowBuilder().addComponents(emojiInput),
      new ActionRowBuilder().addComponents(namingInput),
      new ActionRowBuilder().addComponents(limitInput)
    );

    return modal;
  },

  createEditOptionModal(option) {
    const modal = new ModalBuilder()
      .setCustomId('modal_add_option_part1')
      .setTitle('تعديل الخيار - الجزء 1');

    const nameInput = new TextInputBuilder()
      .setCustomId('option_name')
      .setLabel('اسم الخيار')
      .setStyle(TextInputStyle.Short)
      .setValue(option.name || '')
      .setRequired(true);

    const descInput = new TextInputBuilder()
      .setCustomId('option_description')
      .setLabel('وصف الخيار')
      .setStyle(TextInputStyle.Paragraph)
      .setValue(option.description || '')
      .setRequired(false);

    const emojiInput = new TextInputBuilder()
      .setCustomId('option_emoji')
      .setLabel('الإيموجي')
      .setStyle(TextInputStyle.Short)
      .setValue(option.emoji || '')
      .setRequired(false);

    const namingInput = new TextInputBuilder()
      .setCustomId('option_naming')
      .setLabel('نمط التسمية (ticket-{num}, {user})')
      .setStyle(TextInputStyle.Short)
      .setValue(option.namingPattern || 'ticket-{num}')
      .setRequired(false)
      .setPlaceholder('ticket-{num}');

    const limitInput = new TextInputBuilder()
      .setCustomId('option_limit')
      .setLabel('الحد الأقصى للتذاكر لكل مستخدم')
      .setStyle(TextInputStyle.Short)
      .setValue(option.maxTickets ? option.maxTickets.toString() : '')
      .setRequired(false)
      .setPlaceholder('اتركه فارغاً لعدم وجود حد');

    modal.addComponents(
      new ActionRowBuilder().addComponents(nameInput),
      new ActionRowBuilder().addComponents(descInput),
      new ActionRowBuilder().addComponents(emojiInput),
      new ActionRowBuilder().addComponents(namingInput),
      new ActionRowBuilder().addComponents(limitInput)
    );

    return modal;
  },

  createAddOptionPart2Modal() {
    const modal = new ModalBuilder()
      .setCustomId('modal_add_option_part2')
      .setTitle('إضافة خيار جديد - الجزء 2');

    const adminRoleInput = new TextInputBuilder()
      .setCustomId('option_admin_role')
      .setLabel('معرف الرتبة المسؤولة (اختياري)')
      .setStyle(TextInputStyle.Short)
      .setRequired(false)
      .setPlaceholder('معرف الرتبة التي يمكنها رؤية التذاكر');

    const categoryInput = new TextInputBuilder()
      .setCustomId('option_category')
      .setLabel('معرف الفئة (Category ID) (اختياري)')
      .setStyle(TextInputStyle.Short)
      .setRequired(false)
      .setPlaceholder('معرف الفئة التي ستنشأ فيها التذاكر');

    modal.addComponents(
      new ActionRowBuilder().addComponents(adminRoleInput),
      new ActionRowBuilder().addComponents(categoryInput)
    );

    return modal;
  },

  createEditEmbedTitleModal(currentValue = '') {
    const modal = new ModalBuilder()
      .setCustomId('modal_edit_embed_title')
      .setTitle('تعديل عنوان الإيمبد');

    const titleInput = new TextInputBuilder()
      .setCustomId('embed_title')
      .setLabel('العنوان')
      .setStyle(TextInputStyle.Short)
      .setValue(currentValue)
      .setRequired(false);

    modal.addComponents(new ActionRowBuilder().addComponents(titleInput));
    return modal;
  },

  createEditEmbedDescModal(currentValue = '') {
    const modal = new ModalBuilder()
      .setCustomId('modal_edit_embed_description')
      .setTitle('تعديل وصف الإيمبد');

    const descInput = new TextInputBuilder()
      .setCustomId('embed_description')
      .setLabel('الوصف')
      .setStyle(TextInputStyle.Paragraph)
      .setValue(currentValue)
      .setRequired(false);

    modal.addComponents(new ActionRowBuilder().addComponents(descInput));
    return modal;
  },

  createEditEmbedImagesModal(thumbnail = '', image = '') {
    const modal = new ModalBuilder()
      .setCustomId('modal_edit_embed_images')
      .setTitle('تعديل صور الإيمبد');

    const thumbnailInput = new TextInputBuilder()
      .setCustomId('embed_thumbnail')
      .setLabel('رابط الأيقونة (Thumbnail)')
      .setStyle(TextInputStyle.Short)
      .setValue(thumbnail || '')
      .setRequired(false);

    const imageInput = new TextInputBuilder()
      .setCustomId('embed_image')
      .setLabel('رابط الصورة (Image)')
      .setStyle(TextInputStyle.Short)
      .setValue(image || '')
      .setRequired(false);

    modal.addComponents(
      new ActionRowBuilder().addComponents(thumbnailInput),
      new ActionRowBuilder().addComponents(imageInput)
    );
    return modal;
  },

  createEditEmbedFooterModal(footerText = '', footerIcon = '') {
    const modal = new ModalBuilder()
      .setCustomId('modal_edit_embed_footer')
      .setTitle('تعديل تذييل الإيمبد');

    const textInput = new TextInputBuilder()
      .setCustomId('embed_footer_text')
      .setLabel('نص التذييل')
      .setStyle(TextInputStyle.Short)
      .setValue(footerText || '')
      .setRequired(false);

    const iconInput = new TextInputBuilder()
      .setCustomId('embed_footer_icon')
      .setLabel('رابط أيقونة التذييل')
      .setStyle(TextInputStyle.Short)
      .setValue(footerIcon || '')
      .setRequired(false);

    modal.addComponents(
      new ActionRowBuilder().addComponents(textInput),
      new ActionRowBuilder().addComponents(iconInput)
    );
    return modal;
  },

  createEditEmbedColorModal(currentColor = '#5865F2') {
    const modal = new ModalBuilder()
      .setCustomId('modal_edit_embed_color')
      .setTitle('تعديل لون الإيمبد');

    const colorInput = new TextInputBuilder()
      .setCustomId('embed_color')
      .setLabel('اللون (HEX)')
      .setStyle(TextInputStyle.Short)
      .setValue(currentColor)
      .setRequired(false)
      .setPlaceholder('#5865F2');

    modal.addComponents(new ActionRowBuilder().addComponents(colorInput));
    return modal;
  },

  createCloseReasonModal() {
    const modal = new ModalBuilder()
      .setCustomId('modal_close_reason')
      .setTitle('إغلاق التذكرة');

    const reasonInput = new TextInputBuilder()
      .setCustomId('close_reason')
      .setLabel('سبب الإغلاق')
      .setStyle(TextInputStyle.Paragraph)
      .setRequired(true);

    modal.addComponents(new ActionRowBuilder().addComponents(reasonInput));
    return modal;
  },

  createRatingsSettingsModal(currentChannelId = '', isEnabled = false) {
    const modal = new ModalBuilder()
      .setCustomId('modal_ratings_settings')
      .setTitle('إعدادات التقييمات');

    const channelInput = new TextInputBuilder()
      .setCustomId('ratings_channel_id')
      .setLabel('ايدي قناة التقييمات')
      .setStyle(TextInputStyle.Short)
      .setValue(currentChannelId)
      .setRequired(true)
      .setPlaceholder('أدخل ايدي القناة');

    const enabledInput = new TextInputBuilder()
      .setCustomId('ratings_enabled')
      .setLabel('تفعيل/تعطيل (اكتب: تفعيل أو تعطيل)')
      .setStyle(TextInputStyle.Short)
      .setValue(isEnabled ? 'تفعيل' : 'تعطيل')
      .setRequired(true)
      .setPlaceholder('تفعيل أو تعطيل');

    modal.addComponents(
      new ActionRowBuilder().addComponents(channelInput),
      new ActionRowBuilder().addComponents(enabledInput)
    );
    return modal;
  },

  createRatingMessageModal() {
    const modal = new ModalBuilder()
      .setCustomId('modal_rating_message')
      .setTitle('رسالة التقييم');

    const messageInput = new TextInputBuilder()
      .setCustomId('rating_message')
      .setLabel('رسالتك')
      .setStyle(TextInputStyle.Paragraph)
      .setRequired(false)
      .setPlaceholder('اكتب رسالتك هنا (اختياري)');

    modal.addComponents(new ActionRowBuilder().addComponents(messageInput));
    return modal;
  }
};
