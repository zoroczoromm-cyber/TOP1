
const { ButtonBuilder, ButtonStyle, ActionRowBuilder } = require('discord.js');
const config = require('../config');

module.exports = {
  createEditSectionButtons() {
    return new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('edit_section_add_option')
          .setLabel('اضافة خيار')
          .setStyle(ButtonStyle.Success)
          .setEmoji(config.emojis.add),
        new ButtonBuilder()
          .setCustomId('edit_section_edit_option')
          .setLabel('تعديل الخيار')
          .setStyle(ButtonStyle.Primary)
          .setEmoji(config.emojis.edit),
        new ButtonBuilder()
          .setCustomId('edit_section_edit_embed')
          .setLabel('تعديل الايمبد')
          .setStyle(ButtonStyle.Secondary)
          .setEmoji(config.emojis.notes),
        new ButtonBuilder()
          .setCustomId('edit_section_edit_ticket')
          .setLabel('تعديل التكت')
          .setStyle(ButtonStyle.Secondary)
          .setEmoji(config.emojis.ticket),
        new ButtonBuilder()
          .setCustomId('edit_section_manage_options')
          .setLabel('ادارة الخيارات')
          .setStyle(ButtonStyle.Danger)
          .setEmoji(config.emojis.delete)
      );
  },

  createManageOptionsButtons() {
    return new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('manage_delete_section')
          .setLabel('حذف القسم')
          .setStyle(ButtonStyle.Danger)
          .setEmoji(config.emojis.delete),
        new ButtonBuilder()
          .setCustomId('manage_delete_option')
          .setLabel('حذف خيار')
          .setStyle(ButtonStyle.Danger)
          .setEmoji(config.emojis.deleteOption),
        new ButtonBuilder()
          .setCustomId('manage_delete_all_options')
          .setLabel('حذف جميع الخيارات')
          .setStyle(ButtonStyle.Danger)
          .setEmoji(config.emojis.deleteAll)
      );
  },

  createEmbedEditButtons() {
    return new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('embed_edit_title')
          .setLabel('العنوان')
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId('embed_edit_description')
          .setLabel('الوصف')
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId('embed_edit_images')
          .setLabel('الصور')
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId('embed_edit_footer')
          .setLabel('التذييل')
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId('embed_edit_color')
          .setLabel('اللون')
          .setStyle(ButtonStyle.Primary)
      );
  },

  createRemoveImageButtons() {
    return new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('embed_remove_thumbnail')
          .setLabel('حذف الأيقونة')
          .setStyle(ButtonStyle.Danger),
        new ButtonBuilder()
          .setCustomId('embed_remove_image')
          .setLabel('حذف الصورة')
          .setStyle(ButtonStyle.Danger),
        new ButtonBuilder()
          .setCustomId('embed_back')
          .setLabel('رجوع')
          .setStyle(ButtonStyle.Secondary)
      );
  },

  createPaginationButtons(currentPage, totalPages, prefix = 'page') {
    const row = new ActionRowBuilder();

    if (currentPage > 0) {
      row.addComponents(
        new ButtonBuilder()
          .setCustomId(`${prefix}_prev`)
          .setLabel('السابق')
          .setStyle(ButtonStyle.Primary)
          .setEmoji(config.emojis.prevPage)
      );
    }

    if (currentPage < totalPages - 1) {
      row.addComponents(
        new ButtonBuilder()
          .setCustomId(`${prefix}_next`)
          .setLabel('التالي')
          .setStyle(ButtonStyle.Primary)
          .setEmoji(config.emojis.nextPage)
      );
    }

    return row.components.length > 0 ? row : null;
  },

  createNextButton(customId = 'next_step') {
    return new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId(customId)
          .setLabel('التالي')
          .setStyle(ButtonStyle.Success)
          .setEmoji(config.emojis.next)
      );
  }
};
